﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace FarmMart.Forms
{
   
    public partial class Registration : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-NSME37K;Initial Catalog=dbFarmKart;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtname.Focus();
            }
            

            
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            string gender="";

            if (rbtfarmer.Checked == true)
            { gender = "Customer"; }
            else if (rbtfarmer.Checked == true)
            {
                gender = "Farmer";
            }
            else
            {
                //Response.Write("<srcipt>alert('Please select proper category');</script>");
                rbtfarmer.Focus();
            }

            if (dlstate.Text == "--Select State--")
            {
             //   Response.Write("<script>alert('Hello');</script>");

             ////   Response.Write("<srcipt>alert('Please select proper state');</script>");
                dlstate.Focus();
            }
            else if (dlcity.Text == "--Select city--")
            {
                //Response.Write("<srcipt>alert('Please select proper city');</script>");
                dlcity.Focus();
            }
            else
            {
                cmd.CommandText = "insert into tblregisteruser(name,mobileno,emailid,state,city,category,username,password) values('" + txtname.Text + "', '" + Convert.ToInt64(txtmoible.Text) + "','" + txtemail.Text + "','" + dlstate.Text + "','" + dlcity.Text + "','" +gender + "','" + txtuserName.Text + "','" + txtpassword.Text + "')";
                cmd.ExecuteNonQuery();
                
                Response.Redirect("index.aspx");
            }

        }
    }
}