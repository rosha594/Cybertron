﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FarmMart
{
    public partial class CustomerDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            kart.Visible = true;
            
            farmerlist.Visible = false;
            purchaseHistory.Visible = false;
        }

        public void makeVisible(object sender, EventArgs e)
        {
           
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            kart.Visible = true;
            
            farmerlist.Visible = false;
            purchaseHistory.Visible = false;
        }

        protected void btnremove_Click(object sender, EventArgs e)
        {
            kart.Visible = false;
            
            farmerlist.Visible = false;
            purchaseHistory.Visible = true;
        }

        protected void btnfarmerlist_Click(object sender, EventArgs e)
        {
            kart.Visible = false;
            
            purchaseHistory.Visible = false;
            farmerlist.Visible = true;
        }
    }
}