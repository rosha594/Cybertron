﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FarmMart
{
    public partial class FarmerDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Addpanel.Visible = true;
            salepanel.Visible = false;
            removepanel.Visible = false;
            updatepanel.Visible = false;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
           
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
          
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            Addpanel.Visible = true;
            salepanel.Visible = false;
            removepanel.Visible = false;
            updatepanel.Visible = false;
        }

        protected void btnremove_Click(object sender, EventArgs e)
        {
            Addpanel.Visible = false;
            salepanel.Visible = false;
            removepanel.Visible = true;
            updatepanel.Visible = false;
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            Addpanel.Visible = false;
            salepanel.Visible = false;
            removepanel.Visible = false;
            updatepanel.Visible = true;
        }
    }
}